import React,{useContext} from 'react'
import { Fav } from '../Context'
 
function ProductCard({item}) {
 
  const {fav,setFav}= useContext(Fav)

  const cartSet = new Set(fav.map((item) => item.id));
 
 
  const handleAddToFavorites = (product) => {
    if (cartSet.has(product.id)) {
      setFav(cart.filter((item) => item.id !== product.id));
    } else {
      setFav([...fav, product]);
    }
  };

  return (
    <div>

<li className="Card" key={item.id}>
        
        <figure className="picture"><img src={item.url} /></figure>
        <div className="contentArea">
        <h3>Album ID : {item.albumId}
        <button
            id={item.id}
            className="addFav"
            onClick={() => handleAddToFavorites(item)}
          >
            {cartSet.has(item.id) ? 'Remove from Favorites' : 'Add to Favorites'}
          </button>
        
        {/* {
        fav.includes(item)?(                      
                             <button id={item.id}  className='addFav'  onClick={()=>{
                             setFav(fav.filter(c=>c.id !==item.id))
                            }}>
                               Remove Favourites
                            </button>)
                            :
                            (
                          <button id={item.id}  className='addFav'  onClick={()=>{
                            setFav([...fav,item])
                            }}>
                            Add to Favourites
                            </button>
                            )
        
                         } */}
        </h3>
        <h3>ID : {item.id}</h3>
        <h2>Title : {item.title}</h2>
        <figure><img src={item.thumbnailUrl}/> </figure>
        </div>
        </li>
            {/* <li key={data.id}>{data.id}<br/>{data.email}  
                    {
                        cart.includes(data)?(                      
                             <button id={data.id}  className='addFav'  onClick={()=>{
                             setCart(cart.filter(c=>c.id !==data.id))
                            }}>
                               Remove Favourites
                            </button>)
                            :
                            (
                          <button id={data.id}  className='addFav'  onClick={()=>{
                            setCart([...cart,data])
                            }}>
                            Add to Favourites
                            </button>
                            )
                    }
              </li> */}
    </div>
  )
}
 
export default ProductCard