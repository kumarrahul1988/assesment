import { useEffect, useState } from "react";
import {Link} from 'react-router-dom'
import InfiniteScroll from 'react-infinite-scroll-component';
import ProductCard from "./ProductCard";


function ListPage(){
    
    const [data, setData] = useState([]);
    const [page, setPage] = useState(1);
    const [totalResult, setTotalResult] = useState(0);
    useEffect(()=>{
       // fetchData();
       fetchMoreData();
    },[])
    
    
    //const  fetchData  =async()=>{}

//console.log(data);
let fetchMoreData = async() => {
    console.log("test1");
   
    setPage(page+1);
    console.log("page :" + page)
    const result = await fetch(`https://jsonplaceholder.typicode.com/albums/1/photos?_page=${page}`);
    const finalResult = await result.json();
   //console.log(JSON.stringify(finalResult));
    //setData((prev) => [...prev, ...finalResult])
    setTimeout(function(){setData([...data.concat(...finalResult)])}, 2000)
    
    setTotalResult(5);
  };

  
return(
    
    <div>

        <div className="backbtn"> <span className="backTag"><Link to="/"> &larr; Back</Link></span></div>
        <ul className="cardContainer">

        <InfiniteScroll
          dataLength={data.length}
          next={fetchMoreData}
          hasMore={data.length!==totalResult}
          loader={<h4><img src="https://upload.wikimedia.org/wikipedia/commons/b/b1/Loading_icon.gif" /></h4>}
        >

{/* {console.log("Final :" + data)} */}

{data.map(function(item, i)  {
       return(
       
       <ProductCard item={item} key={item.id} />
       
      )
      
    })
    
}
  
      

</InfiniteScroll>
    </ul>
    </div>  
  )
  

}


export default ListPage