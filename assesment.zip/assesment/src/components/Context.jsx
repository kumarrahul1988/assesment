import React, { createContext, useState,useEffect } from 'react'

export const Fav =createContext()


const Context=({children})=> {
  
  const storedItem= JSON.parse(localStorage.getItem('fav'))
  console.log(storedItem)

    const [fav,setFav] =useState(storedItem);
    
    
    useEffect(()=>{

      localStorage.setItem("fav",JSON.stringify(fav))
  
    },[fav])


 
    return (
        <Fav.Provider  value={{fav,setFav}}>{children}</Fav.Provider>
  )
}




export default Context