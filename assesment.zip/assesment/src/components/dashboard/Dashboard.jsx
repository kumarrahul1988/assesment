import {Link} from 'react-router-dom'
import { Fav } from '../Context'
import ProductCard from '../listpage/ProductCard'
import { useContext, useEffect } from 'react'

function Dashboard() {

  // const storedItem= JSON.parse(localStorage.getItem('fav'))
  // console.log(storedItem)
  const {fav,setFav}= useContext(Fav)

    return (
        <div className="Dashboard">
     <div className="leftArea">
        <Link to="/ListPage">Link</Link>
     </div>
     
     <div className="contentArea">
    <div>Dashboard</div>
  </div>
  { <div>
            <h1>My Favourites</h1>

            {fav.map((item)=>(
                <ProductCard item={item} key={item.id} fav={fav} setFav={setFav}/>
            ))}
    </div> }

  </div>
    )
  }
  
  export default Dashboard